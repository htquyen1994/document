import React from "react";

export default function DashBoard() {
  return <div>DashBoard</div>;
}
