//c1
const styles = (theme) => {
  return {
    // key là tên của class : value là css của class
    changeBG: {
      backgroundColor: theme.palette.background.timLim,
    },
  };
};
// c2
// const styles = () => ({
//   // key là tên của class : value là css của class
//   changeBG: {
//     backgroundColor: "purple",
//   },
// });

export default styles;
