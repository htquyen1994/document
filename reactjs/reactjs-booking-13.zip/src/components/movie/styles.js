const styles = () => ({
  setHeight: {
    height: "300px",
  },
});

export default styles;
