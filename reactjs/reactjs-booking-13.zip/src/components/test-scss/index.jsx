import React from "react";
import "./styles.scss";
export default function TestSCSS() {
  return (
    <div>
      <h1 className="demo__sass">DEMO SASS</h1>
    </div>
  );
}
